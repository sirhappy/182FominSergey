﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RobotLib;

namespace Homework01
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Robot rob;

        public MainWindow()
        {
            InitializeComponent();
            rob = new Robot();
        }

        private void Update(object sender, RoutedEventArgs e)
        {
            canvasMain.Width = gridMain.ActualWidth;
            canvasMain.Height = gridMain.ActualHeight;
            Drawer.DrawField(canvasMain, fieldX, fieldY);
            canvasMain.Children.Clear();
            Line line = Drawer.DrawLine(0, 0, 10000, 10000);
            canvasMain.Children.Add(line);
        }

        int fieldX, fieldY;

        private void TextBox_TextChanged_Field_Y(object sender, TextChangedEventArgs e)
        {
            fieldY = int.Parse(((TextBox)sender).Text);
        }

        private void TextBox_TextChanged_Field_X(object sender, TextChangedEventArgs e)
        {
            fieldX = int.Parse(((TextBox)sender).Text);
        }
    }

    public class Drawer
    {
        public static void DrawField(Canvas canvas, int x, int y)
        {
            canvas.Background = Brushes.Aqua;
            canvas.Children.Add(DrawLine(0, 0, 1000, 1000));
            double width = canvas.ActualWidth;
            double height = canvas.ActualHeight;
            for (double i = 0; i <= x; ++i)
            {
                canvas.Children.Add(DrawLine(i / x * width, 0, i / x * width, height));
            }
            for (double i = 0; i <= y; ++i)
            {
                canvas.Children.Add(DrawLine(0, i / y * height, width, i / y * height));
            }
        }

        public static Line DrawLine(double x1, double y1, double x2, double y2)
        {
            Line line = new Line();
            line.X1 = x1;
            line.Y1 = y1;
            line.X2 = x2;
            line.Y2 = y2;
            line.Stroke = Brushes.Black;
            line.Width = 10;
            line.HorizontalAlignment = HorizontalAlignment.Left;
            line.VerticalAlignment = VerticalAlignment.Center;
            return line;
        }
    }
}
