﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    interface IFunction
    {
        double Function(double x);
    }


    delegate double Calculate(double x);

    class F : IFunction
    {
        Calculate c;
        public F(Calculate del)
        {
            c = del;
        }

        public double Function(double x)
        {
            return c.Invoke(x);
        }
    }
}
