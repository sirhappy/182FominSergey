﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fomin_SR4_var3
{
    class Program
    {
        static void Main(string[] args)
        {
            do
            {
                Console.WriteLine("Введите A: ");
                int a = 0, b = 0;
                try
                {
                    a = int.Parse(Console.ReadLine());
                    if (a > 1000 || a < -1000) throw new ArgumentOutOfRangeException();

                    b = int.Parse(Console.ReadLine());
                    if (b > 1000 || b < -1000) throw new ArgumentOutOfRangeException();
                }
                catch (ArgumentNullException)
                {
                    Console.WriteLine("Неверный формат ввода!");
                }
                catch (FormatException)
                {
                    Console.WriteLine("Неверный формат ввода!");
                }
                catch (ArgumentOutOfRangeException)
                {
                    Console.WriteLine("Координаты должны быть от -1000 до 1000!");
                }
                Square square = new Square(new Coordinate(a, b));

                // не успел...

                Console.WriteLine("Нажмите ESC для выхода");
            } while (Console.ReadKey(true).Key != ConsoleKey.Escape);
        }

        public void PrintInfo(object sender, EventArgs e)
        {
            Coordinate c = sender as Coordinate;
            Console.WriteLine(c.A + " " + c.B);
        }
    }

    class Square
    {
        public Square(Coordinate coordinate)
        {
            Coordinates = coordinate;
        }

        const int Side = 10;

        public delegate void CoordinateChanged(object sender, EventArgs e);
        public event CoordinateChanged OnCoordinateChanged;

        private Coordinate coordinate;

        public Coordinate Coordinates
        {
            get => coordinate;
            set
            {
                coordinate = value;
                OnCoordinateChanged?.Invoke(coordinate, new EventArgs());
            }
        }
    }

    class Coordinate
    {
        public int A { get; set; }

        public int B { get; set; }

        public Coordinate(int a, int b)
        {
            A = a;
            B = b;
        }

        public Coordinate()
        {
            A = 0;
            B = 0;
        }
    }
}
